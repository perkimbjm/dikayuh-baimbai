<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1,user-scalable=no,maximum-scale=1,width=device-width">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="author" content="rasyid">
    
  <link href="{{ asset('img/logo.png') }}" rel="shortcut icon" type="image/png">
  <title>Peta Kekumuhan Banjarmasin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css">
  <link rel="stylesheet" href="{{ asset('css/fullscreen.css') }}">
  <link rel="stylesheet" href="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-locatecontrol/v0.43.0/L.Control.Locate.css">
  <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
  <link rel="stylesheet" href="{{ asset('css/app.css') }}">
  <style>
    html, body, #container {
      height: 100%;
      width: 100%;
      overflow: hidden;
    }
    #container {
      margin-top: 55px;
    }

    .navbar {
      border-color: #bbb;
    }
    .navbar-brand {
      font-weight: bold;
    }
    .white {
      color: #fff;
    }
  .tg  {border-collapse:collapse;border-spacing:0;}
  .tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:11px;
    overflow:hidden;padding:8px 5px;word-break:normal;}
  .tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:11px;
    font-weight:normal;overflow:hidden;padding:8px 5px;word-break:normal;}
  .tg .tg-zjf3{background-color:#34cdf9;border-color:inherit;
    font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif !important;;font-weight:bold;text-align:left;
    vertical-align:top}
  .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
  .tg .tg-vquk{background-color:#34cdf9;font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif !important;;font-weight:bold;
    text-align:left;vertical-align:top}
  .tg .tg-0lax{text-align:left;vertical-align:top}

  .leaflet-tooltip.no-background {
    background: transparent;
    border: none;
    box-shadow: none;
    color: none;
    -webkit-text-stroke-width: 0.9px;
    -webkit-text-stroke-color: whitesmoke;
    -webkit-text-fill-color: black;
  }
  </style>
</head>

<body>
  
  <div id="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="/"><b><i class="fas fa-map-marker-alt"></i> Webmap Banjarmasin</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link text-light" href="/ded" target="_blank"><i class="fas fa-file-alt"></i> Form Input DED</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="https://docs.google.com/spreadsheets/d/1KAWaSMvZIu_FKmHO9rH0XlvnjZwPIzzh6PGTPet03Xw/edit?usp=sharing" target="_blank"><i class="fas fa-table"></i> Data DED</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="/usulan" target="_blank"><i class="fas fa-file-alt"></i> Form Verifikasi Usulan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="https://docs.google.com/spreadsheets/d/16JwuNGY4lQeKiOuthP2ActIyC0iDdMD3Pl9h3XEswic/edit?usp=sharing" target="_blank"><i class="fas fa-table"></i> Data Musrenbang</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="#" data-toggle="modal" data-target="#infoModal"><i class="fas fa-info-circle"></i> Info</a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header alert-dark">
            <h5 class="modal-title" id="exampleModalCenterTitle"><i class="fas fa-info-circle"></i> Info</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <table class="table table-sm">
              <tr>
                <td>Disclaimer : WebGIS dalam pengembangan, batas daerah hanya berupa data indikatif.</td>
              </tr>
            </table>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Tutup</button>
          </div>
        </div>
      </div>
    </div>
    <div id="map"></div>
  </div>

  <div class="modal fade" id="featureModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button class="close" type="button" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title text-primary" id="feature-title"></h4>
        </div>
        <div class="modal-body" id="feature-info"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
  <script src="https://unpkg.com/esri-leaflet@3.0.10/dist/esri-leaflet.js"></script>
  <script src="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-locatecontrol/v0.43.0/L.Control.Locate.min.js"></script>
  <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
  <script src="{{ asset('js/L.Control.Fullscreen.min.js') }}"></script>
  <script src="{{ asset('js/leaflet.markercluster141.js') }}"></script>
  <script src="{{ asset('js/basemap.js') }}"></script>
  <script src="{{ asset('js/leaflet.groupedlayercontrol.js') }}"></script>
  <script src="{{ asset('js/L.Geoserver.js') }}"></script>
  <script>
    window.bearerToken = "Bearer {{ config('services.bearer_token') }}";
  </script>
  <script src="{{ asset('js/webgis.js') }}"></script>

  <!-- <script type="text/javascript">        
    if (window.location.protocol != "https:") {
       window.location.protocol = "https";
    }
  </script> -->
</body>

</html>